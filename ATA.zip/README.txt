Execute the scripts in the following order:

1) create_ata.sql
2) constraints_ata.sql
3) load_ata.sql

